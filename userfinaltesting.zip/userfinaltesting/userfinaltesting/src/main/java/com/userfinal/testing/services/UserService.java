package com.userfinal.testing.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.userfinal.testing.dao.UserFinalDao;
import com.userfinal.testing.entities.UserPayDetails;


@Component
public class UserService {
	
	@Autowired
	private UserFinalDao userDao;
	
	
	
	public UserPayDetails addUser(UserPayDetails userpay) {
		
		UserPayDetails user=this.userDao.save(userpay);
		return user;
	}
	
	public List<UserPayDetails> getUser(){
		List<UserPayDetails> findUsers = (List<UserPayDetails>)this.userDao.findAll();
		return findUsers;
	}
	
	public int getDeviceId() {
		List<UserPayDetails> findUsers = (List<UserPayDetails>)this.userDao.findAll();
		int deviceId=0;
		for(UserPayDetails u:findUsers) {
			deviceId= u.getDeviceId();
		}
		
		return deviceId;
	}
	


}
