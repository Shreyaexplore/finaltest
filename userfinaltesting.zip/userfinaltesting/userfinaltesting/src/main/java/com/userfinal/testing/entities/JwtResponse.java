package com.userfinal.testing.entities;

import lombok.Data;

@Data
public class JwtResponse {
	
	
		
		private String jwtToken;

		public String getJwtToken() {
			return jwtToken;
		}

		public void setJwtToken(String jwtToken) {
			this.jwtToken = jwtToken;
		}


}
