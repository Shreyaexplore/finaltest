package com.userfinal.testing.dao;

import org.springframework.data.repository.CrudRepository;

import com.userfinal.testing.entities.UserPayDetails;



public interface UserFinalDao extends CrudRepository<UserPayDetails, Integer> {

}
