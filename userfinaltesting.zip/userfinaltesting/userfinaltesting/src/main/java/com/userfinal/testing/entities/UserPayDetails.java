package com.userfinal.testing.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;



@Entity
@Table(name="userinfo")
public class UserPayDetails {
	
	
		@Id
		@Column(name="DeviceId")
		@NotNull(message="the above field must not be null")
		@Min(1)
		private int deviceId;
		
		@Column(name="RecordType")
		@NotEmpty(message="the recordtype cannot be empty")
		private String recordtype;
		
		@Column(name="Date")
		private Date date;
		
		@Column(name="FieldA")
		private String fieldA;
		
		@Column(name="FieldB")
		private float fieldB;

		
		
		


		

		public int getDeviceId() {
			return deviceId;
		}



		public void setDeviceId(int deviceId) {
			this.deviceId = deviceId;
		}



		public String getRecordtype() {
			return recordtype;
		}



		public void setRecordtype(String recordtype) {
			this.recordtype = recordtype;
		}



		public Date getDate() {
			return date;
		}



		public void setDate(Date date) {
			this.date = date;
		}



		public String getFieldA() {
			return fieldA;
		}



		public void setFieldA(String fieldA) {
			this.fieldA = fieldA;
		}



		public float getFieldB() {
			return fieldB;
		}



		public void setFieldB(float fieldB) {
			this.fieldB = fieldB;
		}



		public UserPayDetails() {
			super();
			// TODO Auto-generated constructor stub
		}



		public UserPayDetails(@NotNull int deviceId, @NotNull String recordtype, @NotNull Date date, String fieldA,
				float fieldB) {
			super();
			this.deviceId = deviceId;
			this.recordtype = recordtype;
			this.date = date;
			this.fieldA = fieldA;
			this.fieldB = fieldB;
		}
		
	}


