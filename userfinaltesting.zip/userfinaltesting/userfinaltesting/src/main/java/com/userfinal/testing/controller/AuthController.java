package com.userfinal.testing.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.userfinal.testing.entities.JwtRequest;
import com.userfinal.testing.entities.JwtResponse;
import com.userfinal.testing.security.JwtTokenHelper;
import com.userfinal.testing.services.UService;

@RestController
@RequestMapping("/auth/")
public class AuthController {
	@Autowired
	private JwtTokenHelper jwtHelper;
	
	@Autowired
	private UService uService;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	
	@PostMapping("/login")
	public ResponseEntity<JwtResponse> createToken(@RequestBody JwtRequest jwtRequest) throws Exception{
		
		this.authenticate(jwtRequest.getUsername(), jwtRequest.getPassword());
		
		UserDetails userDetail = this.uService.loadUserByUsername(jwtRequest.getUsername());
		String token = this.jwtHelper.generateToken(userDetail);
		
		JwtResponse response=new JwtResponse();
		response.setJwtToken(token);
		return new ResponseEntity<JwtResponse>(response,HttpStatus.OK);
	}


	private void authenticate(String username, String password) throws Exception {
		// TODO Auto-generated method stub
		
		UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken
		=new UsernamePasswordAuthenticationToken(username, password);
		
		
			
			try {
				this.authenticationManager.authenticate(usernamePasswordAuthenticationToken);
			} catch (BadCredentialsException e) {
				// TODO: handle exception
				throw new Exception("Invalid username or password");
			}
		
		
	}


}
